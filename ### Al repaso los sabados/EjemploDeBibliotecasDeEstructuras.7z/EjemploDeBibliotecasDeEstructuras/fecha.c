#include "fecha.h"

eFecha construirFecha(int dia,int mes,int anio)
{
    eFecha aux;
    aux.dia=dia;
    aux.mes=mes;
    aux.anio=anio;
}

